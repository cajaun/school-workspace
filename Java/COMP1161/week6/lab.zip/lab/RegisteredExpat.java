interface RegisteredExpat {
  String getWorkPermit();
}
