interface Consultant {
  public double earnFromSkill();
}
