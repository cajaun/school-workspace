interface Citizen {
  public String getTRN();

}